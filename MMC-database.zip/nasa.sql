--
-- Database: `nasa`
--

-- --------------------------------------------------------

--
-- Table structure for table `acronym_define`
--

CREATE TABLE `acronym_define` (
  `id` int(11) NOT NULL,
  `acronym_def` varchar(10) NOT NULL,
  `meaning_def` varchar(75) NOT NULL,
  `definition` varchar(1000) DEFAULT 'No Entries yet',
  `user_rating` int(11) NOT NULL DEFAULT '0',
  `csourced` tinyint(1) NOT NULL,
  `contributor` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acronym_define`
--

INSERT INTO `acronym_define` (`id`, `acronym_def`, `meaning_def`, `definition`, `user_rating`, `csourced`, `contributor`) VALUES
(1, 'A', 'Ampere', ' The ampere (SI unit symbol: A, dimension symbol: I),[1] often shortened to "amp",[2] is a unit of electric current. In the\r\n  International System of Units (SI)[3][4] the ampere is one of the seven[5] SI base units. It is named after André-Marie Ampère (1775–1836),\r\n  French mathematician and physicist, considered the father of electrodynamics.\r\n\r\n    SI defines the ampere in terms of other base units by measuring the electromagnetic force between electrical conductors carrying electric\r\n  current. The earlier CGS measurement system had two different definitions of current, one essentially the same as the SI''s and the\r\n  other using electric charge as the base unit, with the unit of charge defined by measuring the force between two charged metal plates.\r\n  The ampere was then defined as one coulomb of charge per second.[6] In SI, the unit of charge, the coulomb, is defined as the charge\r\n  carried by one ampere during one second.', 2, 1, 'John Doe'),
(7, 'EMC', 'Electronic Counter-measures', 'An electronic countermeasure (ECM) is an electrical or electronic device designed to trick or deceive radar, sonar or other detection systems, like infrared (IR) or lasers. It may be used both offensively and defensively to deny targeting information to an enemy. The system may make many separate targets appear to the enemy, or make the real target appear to disappear or move about randomly. It is used effectively to protect aircraft from guided missiles. Most air forces use ECM to protect their aircraft from attack. It has also been deployed by military ships and recently on some advanced tanks to fool laser/IR guided missiles. It is frequently coupled with stealth advances so that the ECM systems have an easier job. Offensive ECM often takes the form of jamming. Defensive ECM includes using blip enhancement and jamming of missile terminal homers.', 0, 1, 'Sleigh Presty'),
(8, 'TLTC', 'Too Long To Count', 'A witty comeback that a NASA scientist once said to a smart-mouthed reporter who asked her how many acronyms they have. Atta Girl!', 0, 1, 'Hun Gerr'),
(9, 'DGG', 'Dynamic General Guardian', 'A mechanical automaton created by Dr. Bian Zoldark. During a fight with the Inspectors, the pilot, Sanger Zonvolt, was forced to use this mech even though all of its long-distance capabilities were not yet ready. With the fast coding skills of major Filio however, the Dynamic General Guardian was given a new life. Currently, its weapons OS is optimized for sword combat only.', 4, 1, 'Doran E.X. Plorer'),
(10, 'A', 'Analog Signal', 'An analog signal is any time-varying and continuous signal whose time-variance quantity acts as an indicator to another time-varying signal. Analog signals need to use some certain property of it medium to be able to convey its information. This is done through changes in physical phenomena. For example, an analog signal passing through glass with a certain index of refraction can exploit this is a means of transferring its information. The physical variable is then converted into electrical energy. The fluctuations of the voltage or current of the electricity is then said to be the "analog" of the signal.', 4, 1, 'Dartegnian Velarde'),
(11, 'HC', 'Hybrid Computer', 'Hybrid computers are generally seen as devices that combine analog and  digital components. Analog components are mostly recognized through their functions as tools in solving complex mathematical computations. The digital component, on the other hand, digital components take care of the controlling services need to stay.Nowadays hybrid computers are prevalent in the form of mobile laptops which are usually detachable from their keyboards. ', 0, 1, 'Eugene Delfin'),
(12, 'A&A', 'Advertise And Award', 'Looks like this article is devoid of all signs of life!', 0, 1, 'Jane Dough'),
(13, 'A&CO', 'Activation And Checkout', '', 0, 1, 'Jane Dough'),
(14, 'AGG', 'Aggregate', '', 4, 1, 'Jane Dough'),
(15, 'AV', 'Avalon', '', 0, 1, 'Jane Dough'),
(16, 'B&P', 'Budgetary And Planning', '', 0, 1, 'Jane Dough'),
(17, 'B-L', 'Bill Of Lading', '', 0, 1, 'Hun Gerr'),
(18, 'B/A', 'Barometric', '', 0, 1, 'Sleigh Presty'),
(19, 'C', 'Coefficient', '', 0, 1, 'Hun Gerr'),
(20, 'C', 'Complete', '', 0, 1, 'Jane Dough'),
(21, 'D', 'Discrete', '', 0, 1, 'Sleigh Presty'),
(22, 'D', 'Drag', '', 0, 1, 'Sleigh Presty');

-- --------------------------------------------------------

--
-- Table structure for table `acronym_masterlist`
--

CREATE TABLE `acronym_masterlist` (
  `acronym` varchar(15) NOT NULL,
  `meaning` varchar(75) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acronym_masterlist`
--

INSERT INTO `acronym_masterlist` (`acronym`, `meaning`) VALUES
('', ''),
('A', 'Ampere'),
('A', 'Analog Signal'),
('A&A', 'Advertise And Award'),
('A&CO', 'Activation And Checkout'),
('AGG', 'Aggregate'),
('AV', 'Avalon'),
('B&P', 'Budgetary And Planning'),
('B-L', 'Bill Of Lading'),
('B/A', 'Barometric'),
('C', 'Coefficient'),
('C', 'Complete'),
('C', 'Constant'),
('D', 'Discrete'),
('D', 'Drag'),
('D&C', 'Displays and Controls'),
('DGG', 'Dynamic General Guardian'),
('E', 'Elastic Modulus'),
('E', 'Elevation Angle'),
('E&D', 'Engineering and Development'),
('EMC', 'Electronic Counter-measures'),
('F&D', 'Fill and Drain'),
('F&E', 'Facility and Environment'),
('F&S', 'Fabrication and Assembly'),
('GACU', 'Ground Air Conditioning Unit'),
('GACU', 'Ground Avionics Cooling Unit'),
('GADG', 'Gravity or Acceleration due to Gravity'),
('HC', 'High Carbon'),
('HC', 'Hybrid Computer'),
('HCCB', 'Hardware Configuration Control Board'),
('HYDAC', ''),
('IAS', 'Institute of Aeronautical Sciences'),
('IAS', 'Integrated Avionics Subsystem'),
('IASS', 'Inverter/ATCS Support Structure'),
('JTA', 'Job Task Analysis'),
('JTG', 'Joint Training Group'),
('JTIDS', 'Joint Tactical Integrated Display Systems'),
('KCV', 'KKV Carrier Vehicle'),
('KDMS', 'Kennedy Data Management System'),
('KDN', 'Kinetically Designed Nozzle'),
('KDS', 'Kennedy-developed Software'),
('LAT', 'Lot Accecptance Test'),
('LATRS', 'Laser Acquisition and Tracking System'),
('LAW', 'Low-altitude Weapon'),
('MA&SE', 'Mission Analysis and System Engineering'),
('MA&T', 'Manufacturing Assembly and Test'),
('MAA', 'Mathematical Association of America'),
('MOD', 'Modulo'),
('NDST', 'Nondimensional Special Tool'),
('NDT', 'Nondestructive Test'),
('NDT', 'Nondestructive Testing'),
('OASCB', 'Orbiter Avionics Software Control Board'),
('OASIS', 'Oceanic and Atmospheric Scientific Information System'),
('OASIS', 'Orbit Avionics Software Integration Study'),
('PACE', 'Power and Control Electronics'),
('PACE', 'Prelaunch Automatic Checkout Equipment'),
('PACE', 'Producible Alternative to Cadmium-telluride Epitaxy'),
('QRI', 'Quick-reaction Integration'),
('QRIA', 'Quick-reaction Integration Activity'),
('QRS', 'Qualification Review Sheet'),
('RABF', 'Radio Astronomy Bandstop Filter'),
('RAC', 'Reliability Action Center'),
('RACCS', 'Remote Automatic Checkout and Calibration System'),
('s/s', 'Symbols per second'),
('scc', 'Standard cubic centimeter'),
('scch', 'Standard cubic centimeters per hour'),
('TD', 'Tesla Drive'),
('TLI', 'Tesla Leicht Institute'),
('TLTC', 'Too Long To Count'),
('w/m', 'Words per minute'),
('wpm', 'Words per minute'),
('wps', 'Words per second');

-- --------------------------------------------------------

--
-- Table structure for table `sample`
--

CREATE TABLE `sample` (
  `key1` int(11) NOT NULL,
  `key2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acronym_define`
--
ALTER TABLE `acronym_define`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ad_fk` (`acronym_def`,`meaning_def`);

--
-- Indexes for table `acronym_masterlist`
--
ALTER TABLE `acronym_masterlist`
  ADD PRIMARY KEY (`acronym`,`meaning`);

--
-- Indexes for table `sample`
--
ALTER TABLE `sample`
  ADD PRIMARY KEY (`key1`,`key2`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acronym_define`
--
ALTER TABLE `acronym_define`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `acronym_define`
--
ALTER TABLE `acronym_define`
  ADD CONSTRAINT `ad_fk` FOREIGN KEY (`acronym_def`,`meaning_def`) REFERENCES `acronym_masterlist` (`acronym`, `meaning`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
